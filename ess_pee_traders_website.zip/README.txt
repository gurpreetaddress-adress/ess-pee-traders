ESS PEE TRADERS WEBSITE
========================
Open index.html in any modern browser to preview the website.

Included:
- Responsive one-page design
- Electrical appliance repair services
- Electrical goods/products section
- 30+ years market presence
- WhatsApp and phone buttons
- Jadeed Road, Baramulla contact section
- Google Maps search button
- Sustainability / repair-more-waste-less section

To publish:
Upload index.html to any static web host (for example your hosting provider).
Replace/add photos and logo later if desired.
